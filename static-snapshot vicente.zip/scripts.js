<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
  
<div class="container-fluid mt-3">
  <div class="row">
    <div class="bg-primary col-12">Navbar</div>
  <div class="row">
    <div class="bg-warning col-4">izquierda</div>
    <div class="bg-secondary col-4">centro</div>
    <div class="bg-danger col-4">derecha</div>
  <div class="row">
    <div class="bg-danger col-4">izquierda</div>
    <div class="bg-danger col-4">derecha</div>
  </div>
</div>

</body>
</html>